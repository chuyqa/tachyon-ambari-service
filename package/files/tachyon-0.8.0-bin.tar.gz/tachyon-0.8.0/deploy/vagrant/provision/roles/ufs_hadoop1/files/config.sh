#!/usr/bin/env bash

# let mapreduce be able to run against Tachyon
TACHYON_CLIENT_JAR=$(ls /tachyon/clients/client/target/tachyon-client-*-jar-with-dependencies.jar)
echo "export HADOOP_CLASSPATH=\${HADOOP_CLASSPATH}:${TACHYON_CLIENT_JAR}" >> /hadoop/conf/hadoop-env.sh

NODES=`cat /vagrant/files/workers`

# setup hadoop
rm -f /hadoop/conf/slaves
for i in ${NODES[@]}; do
 echo $i >> /hadoop/conf/slaves
done

# choose the last node as namenode
namenode=$i
echo $namenode > /hadoop/conf/masters

# use /disk0, /disk1... as local storage
EXTRA_DISKS=`ls / | grep '^disk'`
DN=""
NN=""
TMP=""
for disk in $EXTRA_DISKS; do
 DN=/${disk}/dfs/dn,$DN
 NN=/${disk}/dfs/nn,$NN
 TMP=/${disk}/hadoop-tmpstore,$TMP
done

[[ "$TMP" == "" ]] && TMP=/tmp/hadoop-tmpstore
cat > /hadoop/conf/core-site.xml << EOF
<configuration>
<property>
  <name>hadoop.tmp.dir</name>
  <value>$TMP</value>
</property>
<property>
  <name>fs.default.name</name>
  <value>hdfs://${namenode}:9000</value>
</property>
<property>
  <name>fs.tachyon.impl</name>
  <value>tachyon.hadoop.TFS</value>
</property>
<property>
  <name>fs.tachyon-ft.impl</name>
  <value>tachyon.hadoop.TFSFT</value>
</property>
</configuration>
EOF

[[ "$DN" == "" ]] && DN=/tmp/hdfs-datanode
[[ "$NN" == "" ]] && NN=/tmp/hdfs-namenode
cat > /hadoop/conf/hdfs-site.xml << EOF
<configuration>
<property>
 <name>dfs.replication</name>
 <value>1</value>
</property>
<property>
 <name>dfs.data.dir</name>
 <value>$DN</value>
</property>
<property>
 <name>dfs.name.dir</name>
 <value>$NN</value>
</property>
<property>
 <name>dfs.support.broken.append</name>
 <value>true</value>
</property>
<property>
 <name>dfs.webhdfs.enabled</name>
 <value>true</value>
</property>
</configuration>
EOF

cat > /hadoop/conf/mapred-site.xml << EOF
<configuration>
<property>
 <name>mapred.job.tracker</name>
 <value>${namenode}:9001</value>
</property>
</configuration>
EOF
