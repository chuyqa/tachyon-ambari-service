#!/usr/bin/env bash

echo 'tachyon.worker.block.heartbeat.timeout.ms=1000000' >> /tachyon/conf/tachyon-site.properties
